from django.urls import path
from .import views

urlpatterns =[
    path("", views.index, name='index'),
    path("ar/" , views.html1 ,name='html1'),
    path("o/" , views.order_list , name='order_list1'),
    path("s/" , views.student, name='Student'),
    
]