# Create your models here.
from django.db import models
class Student(models.Model):
    name = models.CharField(max_length=255)
    age = models.IntegerField()
    grade= models.CharField(max_length=255)
    def is_passing(self):
        if self.grade >= "C":
            return True
        return False
class order(models.Model):
    order_number = models.CharField(max_length=20)
    customer_name = models.CharField(max_length=100)
    order_date = models.DateField()
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    def is_high_value(self):
        return self.total_amount > 1000

    

