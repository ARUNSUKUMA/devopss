from django.shortcuts import render
from . import urls
# Create your views here.
from django.http import HttpResponse
from django.template import loader
from django.shortcuts import render
from.models import order
from.models import Student
def order_list(request):
    orders = order.objects.all()
    return render(request, 'order_list.html', {'orders': orders})
def index(request):
    return HttpResponse("Hello")
def html1(request):
    a =loader.get_template('a.html')
    return HttpResponse(a.render())
def student(request):
    os = Student.objects.all()
    return render(request, 'student.html', {'os': os})
   